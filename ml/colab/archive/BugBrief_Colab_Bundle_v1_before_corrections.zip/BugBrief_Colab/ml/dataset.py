"""Reviewed synthetic data contract and leakage checks. No GPU dependencies."""
import hashlib
import json
import sys
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "backend"))
from app.domain import Ticket

COUNTS = {"train": 300, "validation": 50, "test": 50}


def read_rows(path):
    return [json.loads(line) for line in Path(path).read_text(encoding="utf-8").splitlines() if line.strip()]


def candidate_digest(row):
    content = {key: value for key, value in row.items() if key not in {"reviewed_by", "reviewed_at"}}
    return hashlib.sha256(json.dumps(content, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()).hexdigest()


def validate_bulk_approval(rows, approval, source_path):
    """Validate recorded batch acceptance without inventing individual reviews."""
    check_unique(rows, require_review=False)
    if any(row["reviewed_by"] or row["reviewed_at"] for row in rows):
        raise ValueError("Bulk-approved candidates must keep individual reviewer fields blank")
    if (approval.get("approval_type") != "user_bulk_approval"
            or approval.get("individual_human_review_verified") is not False
            or not approval.get("approved_by") or not approval.get("instruction")
            or approval.get("approved_count") != len(rows)
            or approval.get("export_sha256") != file_digest(source_path)):
        raise ValueError("Bulk approval provenance does not match the source dataset")
    if datetime.fromisoformat(approval["approved_at"]).tzinfo is None:
        raise ValueError("Bulk approval timestamp must include a timezone")
    events = approval.get("examples", [])
    if len(events) != len(rows) or len({event["id"] for event in events}) != len(rows):
        raise ValueError("Bulk approval must cover each candidate exactly once")
    decisions = {event["id"]: event for event in events}
    for row in rows:
        event = decisions.get(row["id"], {})
        if event.get("decision") != "approved" or event.get("sha256") != candidate_digest(row):
            raise ValueError("A candidate changed after user bulk approval")


def validate_row(row, *, require_review=True):
    required = {"id", "family_id", "report", "ticket", "source", "reviewed_by", "reviewed_at"}
    if set(row) != required:
        raise ValueError("Each dataset row must contain exactly: " + ", ".join(sorted(required)))
    for field in ("id", "family_id", "report"):
        if not isinstance(row[field], str) or not row[field].strip():
            raise ValueError(f"{row.get('id', 'row')}: {field} is missing")
    for field in ("reviewed_by", "reviewed_at"):
        if not isinstance(row[field], str) or (require_review and not row[field].strip()):
            raise ValueError(f"{row.get('id', 'row')}: {field} is missing; human review is required")
    if bool(row["reviewed_by"].strip()) != bool(row["reviewed_at"].strip()):
        raise ValueError("Supply both reviewer and review timestamp, or leave both blank")
    if row["source"] != "synthetic" or not 10 <= len(row["report"]) <= 4000:
        raise ValueError("Use synthetic reports between 10 and 4,000 characters")
    if row["reviewed_at"]:
        reviewed = datetime.fromisoformat(row["reviewed_at"].replace("Z", "+00:00"))
        if reviewed.tzinfo is None:
            raise ValueError("reviewed_at must include a timezone")
    Ticket.model_validate(row["ticket"]).check_source(row["report"])


def check_unique(rows, *, require_review=True):
    ids, reports = set(), set()
    for row in rows:
        validate_row(row, require_review=require_review)
        normalized = " ".join(row["report"].casefold().split())
        if row["id"] in ids or normalized in reports:
            raise ValueError("Duplicate row ID or report; remove duplicate examples before splitting")
        ids.add(row["id"]); reports.add(normalized)


def load_splits(directory, *, allow_bulk_approved=False):
    counts = COUNTS
    manifest_path = Path(directory) / "manifest.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8")) if manifest_path.exists() else {}
    if "counts" in manifest:
        counts = validate_counts(manifest["counts"])
    policy = manifest.get("data_policy", "individually_reviewed")
    if policy not in {"individually_reviewed", "user_bulk_approved_synthetic"}:
        raise ValueError("Unsupported dataset approval policy")
    bulk = policy == "user_bulk_approved_synthetic"
    if bulk and not allow_bulk_approved:
        raise ValueError("This dataset has user bulk approval, not individual review; pass --allow-bulk-approved for this experiment")
    result, seen_families, all_rows = {}, set(), []
    for split, count in counts.items():
        path = Path(directory) / f"{split}.jsonl"
        rows = read_rows(path)
        if len(rows) != count:
            raise ValueError(f"{split} requires {count} examples; found {len(rows)}")
        if bulk and split not in manifest.get("sha256", {}):
            raise ValueError("Bulk-approved splits require frozen file hashes")
        if split in manifest.get("sha256", {}) and file_digest(path) != manifest["sha256"][split]:
            raise ValueError(f"{split} changed after freezing; prepare a new dataset version")
        families = {r["family_id"] for r in rows}
        if families & seen_families:
            raise ValueError("A scenario family appears in more than one split")
        seen_families |= families; all_rows.extend(rows); result[split] = rows
    check_unique(all_rows, require_review=not bulk)
    if bulk:
        source_path = Path(directory) / "bulk-approved.jsonl"
        approval_path = Path(directory) / "bulk-approval.json"
        source = read_rows(source_path)
        validate_bulk_approval(source, json.loads(approval_path.read_text(encoding="utf-8")), source_path)
        if {r["id"]: r for r in source} != {r["id"]: r for r in all_rows}:
            raise ValueError("Frozen splits do not match the bulk-approved source")
    return result


def validate_counts(counts):
    if not isinstance(counts, dict) or set(counts) != set(COUNTS):
        raise ValueError("Split counts must specify train, validation, and test")
    if any(type(value) is not int or value <= 0 for value in counts.values()):
        raise ValueError("Each split count must be a positive integer")
    return {split: counts[split] for split in COUNTS}


def file_digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()
